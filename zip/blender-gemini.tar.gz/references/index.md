# Blender Documentation Index

## Categories

### Getting Started
**File:** `getting_started.md`
**Pages:** 9

### Interface
**File:** `interface.md`
**Pages:** 1
